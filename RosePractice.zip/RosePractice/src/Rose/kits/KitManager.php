<?php


namespace Rose\kits;


class KitManager
{

    /**
     * KitManager constructor.
     */
    public function __construct()
    {
    }
}