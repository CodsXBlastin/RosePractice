<?php


namespace Rose\duels;


class DuelManager
{

    /**
     * DuelManager constructor.
     */
    public function __construct()
    {
    }
}