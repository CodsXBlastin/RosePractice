<?php


namespace Rose\broadcast;


class BroadCastManager
{

    /**
     * BroadCastManager constructor.
     */
    public function __construct()
    {
    }
}