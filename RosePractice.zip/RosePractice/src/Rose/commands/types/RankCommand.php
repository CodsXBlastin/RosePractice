<?php


namespace Rose\commands;


use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\utils\TextFormat;
use Rose\Loader;
use Rose\RosePlayer;

 class RankCommand extends PluginCommand
 {


     private $core;
     public $whitelisted = ["xvqle", "TheRealVerge"];

     public function __construct(Loader $core)
     {
         $this->core = $core;
         parent::__construct("setrank", $core);
         $this->setDescription("§r§eset a rank");
         $this->setPermission("rank.cmd");
     }
     public function execute(CommandSender $sender, string $commandLabel, array $args){
         if($sender instanceof RosePlayer){
             if($sender->isOp()) {
                 $sender->sendMessage(TextFormat::GREEN."
§7---------§l§8(§r§eHCLoungeHCF§l§8)§r§7--------
§eLoaded All Rank Moduals...
§9[Rank]       [Value]
§eDefault    0
§eBronze    0
§eSilver    0
§eGold    0
§eDiamond    0
§7----------------------------------------
§cStaff Ranks:
§6TrialMod: 6
§6Mod: 7
§6Admin: 8
§6Head Admin: 9
§6Owner: 10
§7----------------------------------------
§5Content Creator Ranks:
§dFamous: 12
§dPartner: 13
§7--------------------------------------- 
            
              
             ");
                 if(count($args) == 2) {
                     if($args[1] < RosePlayer::HEAD_ADMIN) {
                         $player = $sender->getServer()->getPlayer($args[0]);
                         if($player) {
                             if($player instanceof RosePlayer) {
                                 $player->setRank($args[1]);
                                 $player->sendMessage(TextFormat::GREEN."Your rank has been successfully updated!");
                                 $sender->sendMessage(TextFormat::GREEN."You have successfully updated ".$player->getName()."'s rank!");
                             }
                         }
                     }else {
                         if(in_array(strtolower($sender->getName()), $this->whitelisted) or $sender instanceof ConsoleCommandSender) {
                             $player = $sender->getServer()->getPlayer($args[0]);
                             if($player) {
                                 if($player instanceof RosePlayer) {
                                     $player->setRank($args[1]);
                                     $player->sendMessage(TextFormat::GREEN."Your rank has been successfully updated!");
                                     $sender->sendMessage(TextFormat::GREEN."You have successfully updated ".$player->getName()."'s rank!");
                                 }
                             }
                         }
                     }
                 }
             }
         }
     }
 }

